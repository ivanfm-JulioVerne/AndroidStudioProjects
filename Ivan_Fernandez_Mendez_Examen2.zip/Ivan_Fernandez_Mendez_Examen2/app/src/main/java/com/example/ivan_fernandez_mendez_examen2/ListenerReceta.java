package com.example.ivan_fernandez_mendez_examen2;

public interface ListenerReceta {
    public void pulsaAlimento();
}
