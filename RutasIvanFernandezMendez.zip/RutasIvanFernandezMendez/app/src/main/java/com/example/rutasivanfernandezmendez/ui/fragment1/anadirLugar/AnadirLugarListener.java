package com.example.rutasivanfernandezmendez.ui.fragment1.anadirLugar;

import com.example.rutasivanfernandezmendez.modelo.Lugar;

public interface AnadirLugarListener {
    public void anadirLugar(Lugar lugar);
}
