package com.example.rutasivanfernandezmendez.ui.fragment1.verLugares;

public interface BorrarLugar {
    public void borrarLugar(int position);
}
